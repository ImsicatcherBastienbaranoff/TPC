#include <stdio.h> 
#include <stdlib.h> 

void main(){
	int var = 10;
	printf("le variable est donc %d \n", var);

}
