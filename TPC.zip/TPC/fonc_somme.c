#include <stdio.h>
#include <stdlib.h>


int somme(int nb1, int nb2){
	return nb1 + nb2;
}


void main(){
	int nombre1;
	int nombre2;
	int resultat; 

	printf("Entrer un nombre\n");
	scanf("%d", &nombre1);


	printf("Entrer un autre nombre\n");
	scanf("%d", &nombre2);

	
	resultat = somme(nombre1, nombre2);
	printf("la somme de %d et de %d est donc : %d\n", nombre1, nombre2, resultat);
}

