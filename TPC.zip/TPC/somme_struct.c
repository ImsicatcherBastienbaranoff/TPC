#include <stdio.h>
#include <stdlib.h>


typedef struct result{
	unsigned int resultat;
	unsigned int errno; //la fonction somme retourne -1 comme errno si c'est faux, retourne 1 sinon 
}result;

typedef struct entree{
	unsigned int nombre1;
	unsigned int nombre2;

}entree;

// une addition possède un overflow quand la somme des deux nombre est infèrieure au maximal des deux nombres dont la somme est à faire 
result fonc_somme(entree e){
	result r;
	r.resultat  = e.nombre1 + e.nombre2;
	//obtenir maximal entre e.nombre1 et e.nombre2
	unsigned int max = e.nombre1;
	if(e.nombre2 > e.nombre1){
		max = e.nombre1;
	}
	
	if(r.resultat > max){
		r.errno = 0;
	}else{
		r.errno = 1;
	}
	return r;
}
void main(){
	unsigned int nb1;
	unsigned int nb2;
	printf("veuillez entrer un nombre \n");
	scanf("%u", &nb1);
	printf("veuillez entrer un autre nombre \n");
	scanf("%u", &nb2);
	
	entree t;
	t.nombre1 = nb1;
	t.nombre2 = nb2;
	result rr = fonc_somme(t);
	if( rr.errno ==  0){
		printf("la somme de %u et de %u donne %u\n", t.nombre1, t.nombre2, rr.resultat);
	}else{
		printf("erreur de la somme\n");
	}

}
