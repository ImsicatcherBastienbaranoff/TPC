#include <stdio.h>
#include <stdlib.h>

void main(){

	printf("hello world\n");
}
