#include <stdio.h>
#include <stdlib.h>

typedef struct result{
	unsigned int resultat;
	unsigned int errno;
}result;
result somme(unsigned int nb1, unsigned int nb2){
	result rr;
	rr.resultat = nb1 + nb2;
	//obtenir maximal 
	unsigned int max = nb1;
	if(nb2 > max){
		max = nb2;
	}
	if(rr.resultat > max){
		rr.errno = 0;
	}else {
		rr.errno = 1;
	}
	return rr;
}


void main(){
	unsigned int nombre1;
	unsigned int nombre2;
	result r; 

	printf("Entrer un nombre\n");
	scanf("%u", &nombre1);


	printf("Entrer un autre nombre\n");
	scanf("%u", &nombre2);

	
	r = somme(nombre1, nombre2);
	if (r.errno ==0){
		printf("la somme de %d et de %d est donc : %d\n", nombre1, nombre2, r.resultat);
	} else{
		printf("erreur de la somme\n");
	}
}

