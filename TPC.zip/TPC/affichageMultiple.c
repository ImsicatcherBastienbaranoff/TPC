#include <stdio.h>
#include <stdlib.h>
int main (int argc, char *argv[]){
	int i = 0;

	if(argc == 1){
		printf("pas de paramètre\n");
        }
	else if(argc >= 2){
		for(i = 1; i < argc ; i++){
			printf("le paramètre numero %d est %s \n", i, argv[i]);
		}
	} else {
		printf("le nombre de paramètre est invalide \n");	
	}

}

