#include <stdio.h>
#include <stdlib.h>


void main(){
	int var = 0;
	printf("veuillez entrer un nombre entier\n");
	scanf("%d", &var);
	printf("vous avez entré le nombre : %d \n", var);

}
