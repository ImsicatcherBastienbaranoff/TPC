#include <stdio.h>
#include <stdlib.h>


typedef struct info{
	unsigned int resultat;
	unsigned int errno; //la fonction somme retourne -1 comme errno si c'est faux, retourne 1 sinon 
	unsigned int nombre1;
	unsigned int nombre2;

}info;


// une addition possède un overflow quand la somme des deux nombre est infèrieure au maximal des deux nombres dont la somme est à faire 
void fonc_somme(info *i){
	i->resultat  = i->nombre1 + i->nombre2;
	//obtenir maximal entre i->nombre1 et i->nombre2
	unsigned int max = i->nombre1;
	if(i->nombre2 > i->nombre1){
		max = i->nombre1;
	}
	
	if(i->resultat > max){
		i->errno = 0;
	}else{
		i->errno = 1;
	}
}
void main(){
	unsigned int nb1;
	unsigned int nb2;
	printf("veuillez entrer un nombre \n");
	scanf("%u", &nb1);
	printf("veuillez entrer un autre nombre \n");
	scanf("%u", &nb2);
	
	info data;
	data.nombre1 = nb1;
	data.nombre2 = nb2;
	fonc_somme(&data);
	if(data.errno ==  0){
		printf("la somme de %u et de %u donne %u\n", data.nombre1, data.nombre2, data.resultat);
	}else{
		printf("erreur de la somme\n");
	}

}
