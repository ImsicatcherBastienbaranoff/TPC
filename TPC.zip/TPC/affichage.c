#include <stdio.h>
#include <stdlib.h>


int main (int argc, char *argv[]){
	if(argc == 1){
		printf("pas de paramètre\n");
        }
	else if(argc == 2){
		printf("le paramètre est %s \n", argv[1]);
	} else {
		printf("le nombre de paramètre est invalide \n");	
	}

}
